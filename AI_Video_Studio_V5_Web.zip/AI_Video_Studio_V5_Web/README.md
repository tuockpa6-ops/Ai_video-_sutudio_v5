# AI Video Studio V5 Web (mobile-first)

Bản web dựa trên workflow V5: chủ đề → kịch bản → chia cảnh → tạo ảnh → tạo giọng đọc → ghép MP4. Giao diện tiếng Việt, thiết kế cho điện thoại, nhận API key của người dùng qua các endpoint tương thích OpenAI.

## Tính năng trong bản 5.1
- Responsive trên trình duyệt điện thoại và máy tính.
- API Base URL và API key tùy chỉnh; model chat/ảnh/TTS có thể đổi.
- Kiểm tra API, tạo kịch bản, tự chia cảnh.
- Tạo ảnh cho từng cảnh hoặc toàn bộ cảnh; sửa prompt riêng từng cảnh.
- Tạo giọng đọc MP3 và nghe thử.
- Nhạc nền tải từ điện thoại; chỉnh âm lượng giọng và nhạc.
- Xuất MP4 16:9 hoặc 9:16 với chuyển động zoom nhẹ và tệp phụ đề SRT.
- API key không được ghi vào dự án hoặc localStorage; backend không lưu key vào cấu hình.

## Chạy thử trên máy tính
Yêu cầu Python 3.10+ và FFmpeg.

```bash
# Ubuntu/Debian
sudo apt-get update && sudo apt-get install -y ffmpeg python3-pip
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```
Mở `http://127.0.0.1:8000`. Điện thoại có thể truy cập cùng Wi-Fi qua `http://IP-MAY-TINH:8000`.

Windows: cài FFmpeg, tạo môi trường Python, chạy `pip install -r requirements.txt` rồi `uvicorn app:app --host 0.0.0.0 --port 8000`.

## Triển khai lên hosting
Có `Dockerfile` để triển khai lên nền tảng hỗ trợ Docker và FFmpeg. Thư mục `output/` chứa video xuất; một số hosting miễn phí xóa dữ liệu khi khởi động lại hoặc giới hạn thời gian xử lý. Kiểm tra giới hạn lưu trữ/thời gian chạy trước khi sử dụng. Dùng HTTPS nếu truy cập qua internet.

## Quan trọng về API key và chi phí
- Chỉ dùng API key của chính bạn và nhà cung cấp tin cậy.
- Key được gửi từ trình duyệt đến backend trong yêu cầu bạn kích hoạt; backend không ghi key vào file. Với môi trường nhiều người dùng, hãy thêm xác thực và giới hạn tần suất, hoặc thiết kế vault mã hóa riêng.
- Không đưa key vào mã nguồn, kho Git, ảnh chụp màn hình hoặc file dự án.
- Việc tạo ảnh/giọng nói có thể tốn tiền; model và endpoint phải được nhà cung cấp hỗ trợ. “Tương thích OpenAI” không đảm bảo mọi API đều có endpoint ảnh và TTS giống nhau.
- Dựng MP4 hiện dùng ảnh tĩnh với chuyển động camera nhẹ, không phải sinh các đoạn video AI chuyển động gốc.

## Kiểm tra nhanh
- `/health` kiểm tra ứng dụng và sự hiện diện của FFmpeg.
- `python -m py_compile app.py` kiểm tra cú pháp Python.

## Giới hạn bản hiện tại
- Dựng video cần FFmpeg trên máy chủ; video dài và ảnh độ phân giải cao có thể vượt giới hạn của hosting miễn phí.
- Nếu API ảnh trả URL thay vì base64, máy chủ/trình duyệt cần truy cập được URL đó.
- Tệp MP4/SRT được lưu trong `output/`; cần cơ chế dọn tệp định kỳ khi chạy lâu dài.
