from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import Optional, List
from pathlib import Path
import base64, json, os, re, subprocess, tempfile, urllib.request, urllib.error, uuid, shutil

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'output'; OUT.mkdir(exist_ok=True)
app = FastAPI(title='AI Video Studio V5 Web', version='5.1.0')
app.mount('/static', StaticFiles(directory=ROOT/'static'), name='static')

class ApiConfig(BaseModel):
    base_url: str = 'https://api.openai.com/v1'
    api_key: str = Field(min_length=1, max_length=500)
    script_model: str = 'gpt-4o-mini'
    image_model: str = 'gpt-image-1'
    tts_model: str = 'gpt-4o-mini-tts'
    voice: str = 'alloy'

class ScriptRequest(ApiConfig):
    topic: str = Field(min_length=2, max_length=2000)
    language: str = 'English'
    duration: str = '60–90 seconds'

class ImageRequest(ApiConfig):
    prompt: str = Field(min_length=2, max_length=4000)
    size: str = '1536x1024'

class TTSRequest(ApiConfig):
    text: str = Field(min_length=1, max_length=12000)

class Scene(BaseModel):
    text: str
    image_data: Optional[str] = None
    image_prompt: Optional[str] = None
    duration: float = 5.0

class RenderRequest(BaseModel):
    scenes: List[Scene]
    ratio: str = '16:9'
    voice_data: Optional[str] = None
    music_data: Optional[str] = None
    voice_volume: float = 1.0
    music_volume: float = 0.15
    subtitle: bool = False


def call_api(cfg: ApiConfig, endpoint: str, payload: dict, binary=False):
    base = cfg.base_url.strip().rstrip('/')
    if not base.startswith(('https://','http://')): raise HTTPException(400, 'Base URL phải bắt đầu bằng https:// hoặc http://')
    req = urllib.request.Request(base + endpoint, data=json.dumps(payload, ensure_ascii=False).encode(), headers={'Authorization':'Bearer '+cfg.api_key.strip(),'Content-Type':'application/json'}, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=180) as res:
            raw = res.read()
            return raw if binary else json.loads(raw.decode('utf-8'))
    except urllib.error.HTTPError as e:
        detail = e.read().decode('utf-8','replace')[:1000]
        raise HTTPException(e.code, f'Nhà cung cấp AI trả HTTP {e.code}: {detail}')
    except Exception as e:
        raise HTTPException(502, f'Không kết nối được API: {str(e)[:400]}')

@app.get('/', response_class=HTMLResponse)
def home(): return (ROOT/'static/index.html').read_text(encoding='utf-8')

@app.get('/health')
def health(): return {'ok':True,'ffmpeg':bool(shutil.which('ffmpeg')),'version':'5.1.0'}

@app.post('/api/test')
def test_api(cfg: ApiConfig):
    data=call_api(cfg,'/chat/completions',{'model':cfg.script_model,'messages':[{'role':'user','content':'Reply with exactly: API OK'}],'max_tokens':10})
    answer=(((data.get('choices') or [{}])[0].get('message') or {}).get('content') or '').strip()
    return {'ok':True,'message':answer or 'API kết nối thành công'}

@app.post('/api/script')
def make_script(req: ScriptRequest):
    prompt=(f'Write a compelling YouTube narration about: {req.topic}. Language: {req.language}. Target duration: {req.duration}. '
            'Output narration only, no headings, no markdown, no camera directions. Separate visual beats with blank lines. '
            'Use natural spoken language, a strong hook and clear ending. Do not invent facts; distinguish uncertainty from verified information.')
    data=call_api(req,'/chat/completions',{'model':req.script_model,'messages':[{'role':'system','content':'You are a careful, cinematic YouTube documentary scriptwriter.'},{'role':'user','content':prompt}],'temperature':0.7})
    text=(((data.get('choices') or [{}])[0].get('message') or {}).get('content') or '').strip()
    if not text: raise HTTPException(502,'Model không trả về kịch bản.')
    return {'script':text}

@app.post('/api/image')
def make_image(req: ImageRequest):
    data=call_api(req,'/images/generations',{'model':req.image_model,'prompt':req.prompt,'size':req.size,'n':1})
    item=(data.get('data') or [{}])[0]
    if item.get('b64_json'): return {'image_data':'data:image/png;base64,'+item['b64_json']}
    if item.get('url'): return {'image_url':item['url']}
    raise HTTPException(502,'API ảnh không trả về b64_json hoặc URL. Hãy kiểm tra model/nhà cung cấp.')

@app.post('/api/tts')
def make_tts(req: TTSRequest):
    # Audio endpoint returns binary; common OpenAI-compatible providers support response_format=mp3.
    raw=call_api(req,'/audio/speech',{'model':req.tts_model,'voice':req.voice,'input':req.text,'response_format':'mp3'},binary=True)
    return {'audio_data':'data:audio/mpeg;base64,'+base64.b64encode(raw).decode('ascii')}

def decode_data_url(data: str, suffix: str):
    if not data: return None
    if ',' in data and data.startswith('data:'): data=data.split(',',1)[1]
    try: raw=base64.b64decode(data)
    except Exception: raise HTTPException(400,'Tệp âm thanh/ảnh không đúng định dạng base64.')
    p=OUT/(uuid.uuid4().hex+suffix); p.write_bytes(raw); return p

@app.post('/api/render')
def render(req: RenderRequest):
    if not req.scenes: raise HTTPException(400,'Chưa có cảnh để dựng.')
    ffmpeg=shutil.which('ffmpeg')
    if not ffmpeg: raise HTTPException(500,'Máy chủ chưa cài FFmpeg. Cài FFmpeg rồi khởi động lại ứng dụng.')
    work=OUT/('job_'+uuid.uuid4().hex); work.mkdir()
    width,height=(1280,720) if req.ratio=='16:9' else (720,1280)
    scene_files=[]; srt_lines=[]; elapsed=0.0
    try:
        for i,sc in enumerate(req.scenes,1):
            dur=max(1.5,min(30,float(sc.duration or 5)))
            image_path=decode_data_url(sc.image_data,'.png') if sc.image_data else None
            if image_path is None:
                # Built-in placeholder makes the pipeline runnable even before image generation.
                from PIL import Image, ImageDraw, ImageFont
                im=Image.new('RGB',(width,height),(18,31,52)); d=ImageDraw.Draw(im)
                d.rectangle((0,int(height*.72),width,height),fill=(28,48,69))
                msg=re.sub(r'\s+',' ',sc.text)[:110]
                try: font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',max(18,width//32))
                except: font=ImageFont.load_default()
                lines=[]; line=''
                for word in msg.split():
                    test=(line+' '+word).strip()
                    if d.textbbox((0,0),test,font=font)[2]>width-80 and line: lines.append(line); line=word
                    else: line=test
                if line: lines.append(line)
                y=height*.36
                for ln in lines[:4]: d.text((40,y),ln,font=font,fill='white'); y+=height*.06
                image_path=work/f'scene_{i:03}.png'; im.save(image_path)
            # Scale/crop with gentle Ken Burns zoom using zoompan.
            out=work/f'scene_{i:03}.mp4'
            vf=f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},zoompan=z='min(zoom+0.0008,1.08)':d={int(dur*25)}:s={width}x{height}:fps=25,format=yuv420p"
            cmd=[ffmpeg,'-y','-loop','1','-i',str(image_path),'-t',str(dur),'-vf',vf,'-an','-c:v','libx264','-preset','veryfast','-crf','23',str(out)]
            p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=180)
            if p.returncode: raise HTTPException(500,'FFmpeg lỗi khi dựng cảnh: '+p.stderr[-500:])
            scene_files.append(out)
            srt_lines.append(f'{i}\n{timestamp(elapsed)} --> {timestamp(elapsed+dur)}\n{sc.text.strip()}\n'); elapsed+=dur
        concat=work/'concat.txt'; concat.write_text(''.join("file '"+str(p).replace("'","'\\''")+"'\n" for p in scene_files),encoding='utf-8')
        joined=work/'visual.mp4'
        p=subprocess.run([ffmpeg,'-y','-f','concat','-safe','0','-i',str(concat),'-c','copy',str(joined)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=180)
        if p.returncode: raise HTTPException(500,'Không ghép được các cảnh: '+p.stderr[-400:])
        args=[ffmpeg,'-y','-i',str(joined)]
        voice=decode_data_url(req.voice_data,'.mp3') if req.voice_data else None
        music=decode_data_url(req.music_data,'.mp3') if req.music_data else None
        if voice: args+=['-i',str(voice)]
        if music: args+=['-i',str(music)]
        if voice and music:
            # input 1 voice, input 2 music
            args+=['-filter_complex',f'[1:a]volume={max(0,min(2,req.voice_volume))}[v];[2:a]volume={max(0,min(1,req.music_volume))}[m];[v][m]amix=inputs=2:duration=first:dropout_transition=2[a]','-map','0:v','-map','[a]','-shortest']
        elif voice: args+=['-i'] if False else []; args+=['-map','0:v','-map','1:a','-shortest']
        elif music: args+=['-map','0:v','-map','1:a','-shortest']
        else: args+=['-map','0:v','-an']
        output=OUT/f'AI_Video_Studio_V5_{uuid.uuid4().hex[:8]}.mp4'
        args+=['-c:v','copy','-c:a','aac','-b:a','192k',str(output)]
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=300)
        if p.returncode: raise HTTPException(500,'Không xuất được MP4: '+p.stderr[-700:])
        srt=OUT/(output.stem+'.srt'); srt.write_text('\n'.join(srt_lines),encoding='utf-8')
        return {'ok':True,'video_url':'/output/'+output.name,'subtitle_url':'/output/'+srt.name,'duration_seconds':round(elapsed,1),'note':'MP4 đã dựng. Nếu không tạo ảnh AI, ứng dụng dùng hình giữ chỗ có chữ.'}
    finally:
        shutil.rmtree(work,ignore_errors=True)

def timestamp(t):
    ms=int(round(t*1000)); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000
    return f'{h:02}:{m:02}:{s:02},{ms:03}'

app.mount('/output', StaticFiles(directory=OUT), name='output')
